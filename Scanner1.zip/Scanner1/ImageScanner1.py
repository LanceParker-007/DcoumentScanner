from cv2 import cv2
from tkinter import *
import cv2
from PIL import Image
from PIL import ImageTk
from tkinter import filedialog, Tk
import utlis
import numpy as np


def selectImage():
    # Grab a reference  to the image panels
    global panelA, panelB
    # open a file chooser dialog and allow the user to select
    # an input image
    path = filedialog.askopenfilename()
    # Ensure a file path was selected
    if(len(path) > 0):
        # load the image from disk, convert it to grayscale,
        # and detect
        # edges in it
        widImg = 480
        heiImg = 640
        image = cv2.imread(path)
        image = cv2.resize(image, (widImg, heiImg))
        imgContours = image.copy()
        imgBigContour = image.copy()
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        edged = cv2.Canny(blur, 50, 50)

        # FInd and draw all contours
        contours, hierarchy = cv2.findContours(
            edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(imgContours, contours, -1, (0, 255, 0), 10)

        # Find the Biggest Contour
        biggest, maxArea = utlis.biggestContour(contours)
        if(biggest.size != 0):
            biggest = utlis.reorder(biggest)
            # Draw the biggest contour
            cv2.drawContours(imgBigContour, biggest, -1, (0, 255, 0), 20)
            imgBigContour = utlis.drawRectangle(
                imgBigContour, biggest, 2)
            pts1 = np.float32(biggest)
            pts2 = np.float32(
                [[0, 0], [widImg, 0], [0, heiImg], [widImg, heiImg]])
            matrix = cv2.getPerspectiveTransform(pts1, pts2)
            imgWarped = cv2.warpPerspective(
                image, matrix, (widImg, heiImg))
            # Remove 20 pixels from each side
            imgWarped = imgWarped[10:imgWarped.shape[0] -
                                  10, 10:imgWarped.shape[1]-10]
            imgWarped = cv2.resize(imgWarped, (widImg, heiImg))
        # edged = imgWarped
        # OpenCV represents image in BGR order; Howeve PIL represents
        # image in RGB order, so we need to swap the channels
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Convert the images to PIL format...
        image = Image.fromarray(image)
        imgWarped = Image.fromarray(imgWarped)

        # ...and then to IMageTk format
        image = ImageTk.PhotoImage(image)
        imgWarped = ImageTk.PhotoImage(imgWarped)

        # if the panels are None, initialize them
        if(panelA is None or panelB is None):
            # the first panel will store our original image
            panelA = Label(image=image)
            panelA.image = image
            panelA.pack(side="left", padx=10, pady=10)
            # while the second panel will store the edge map
            panelB = Label(image=imgWarped)
            panelB.image = imgWarped
            panelB.pack(side="right", padx=10, pady=10)
            #  otherwise, update the image panels
        else:
            panelA.configure(image=image)
            panelB.configure(image=imgWarped)
            panelA.image = image
            panelB.image = imgWarped

# initialize the window toolkit along with the two image panels


root = Tk()
panelA = None
panelB = None
me = Menu(root)
root.config(menu=me, background='green')
root.geometry("1500x750")
filemenu = Menu(me)
me.add_cascade(label="File ", menu=filemenu)
filemenu.add_command(label="New")
filemenu.add_separator()
filemenu.add_command(label="Exit", command=root.quit)
helpmenu = Menu(me)
me.add_cascade(label="Help", menu="helpmenu")
# create a button, then when pressed, will trigger a file chooser
# dialog and allow the user to select an input image; then add the
# button the GUI
# txt = Label(
# root, text='Thanks for using this. I know it is the worst application you are ever using.').place(x=550, y=200)
btn = Button(root, text="Select an image", command=selectImage)
btn.pack(fill="both", padx="10", pady="10")
# kick off the GUI
root.mainloop()
